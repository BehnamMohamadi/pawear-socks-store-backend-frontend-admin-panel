const fs = require("node:fs"),
  path = require("node:path");
(async () => {
  const pages = {};
  let html = "";
  for (const url of ["/", "/shop", "/boxes", "/login"]) {
    const samples = [];
    for (let i = 0; i < 4; i++) {
      const start = performance.now(),
        r = await fetch("http://127.0.0.1:3001" + url);
      const body = await r.text();
      if (r.status !== 200) throw Error(url + " " + r.status);
      if (url === "/") html = body;
      samples.push(Math.round(performance.now() - start));
    }
    pages[url] = {
      warmMs: samples.slice(1),
      htmlBytes: Buffer.byteLength(url === "/" ? html : ""),
    };
  }
  const assets = [
    ...new Set(
      [...html.matchAll(/(?:src|href)="([^"]+\.(?:css|js))"/g)].map((m) => m[1]),
    ),
  ];
  const assetBytes = assets.reduce(
    (n, p) => n + fs.statSync(path.join(__dirname, "../public", p)).size,
    0,
  );
  const c = await require("mongodb").MongoClient.connect(
    "mongodb://127.0.0.1:27028/pawear?replicaSet=pawearDev",
  );
  const counts = {};
  for (const name of ["products", "boxes", "orders", "payments", "users"])
    counts[name] = await c.db().collection(name).countDocuments();
  const options = await c.db("admin").command({ getCmdLineOpts: 1 });
  await c.close();
  const result = {
    pages,
    homepageScriptAndStyleBytes: assetBytes,
    assetFiles: assets.length,
    mainDatabaseCounts: counts,
    dataPath: options.parsed.storage.dbPath,
  };
  fs.writeFileSync(
    path.join(__dirname, "final-probe.json"),
    JSON.stringify(result, null, 2),
  );
  console.log(JSON.stringify(result));
})().catch((e) => {
  console.error(e.message);
  process.exitCode = 1;
});
