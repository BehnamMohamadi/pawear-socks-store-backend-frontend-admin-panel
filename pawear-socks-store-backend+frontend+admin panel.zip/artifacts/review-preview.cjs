process.env.NODE_ENV = "test";
process.env.CLIENT_ORIGIN = "http://127.0.0.1:3001";
process.env.SITE_URL = "http://127.0.0.1:3001";
const { restoreIntoNewDatabase } = require("../utils/database-backup");
const mongoose = require("mongoose");
(async () => {
  const uri = "mongodb://127.0.0.1:27028/?replicaSet=pawearDev",
    database = "pawear_test_preview_20260912";
  const client = await require("mongodb").MongoClient.connect(uri);
  const existing = (
    await client.db("admin").admin().listDatabases({ nameOnly: true })
  ).databases.some((d) => d.name === database);
  await client.close();
  if (!existing)
    console.log(
      await restoreIntoNewDatabase({
        uri,
        database,
        directory: "C:/Users/asus/.pawear-backups/2026-09-11T21-08-02-820Z-1a227958",
      }),
    );
  await mongoose.connect(uri, { dbName: database });
  const app = require("../app"),
    User = require("../models/user-model");
  if (!(await User.exists({ phonenumber: "09999999999" })))
    await User.create({
      firstname: "مدیر",
      lastname: "آزمایش",
      phonenumber: "09999999999",
      password: "Preview-only-8462",
      role: "admin",
    });
  app.listen(3001, "127.0.0.1", () =>
    console.log("Isolated preview ready: http://127.0.0.1:3001"),
  );
})().catch((e) => {
  console.error(e.message);
  process.exitCode = 1;
});
