const fs = require("node:fs"),
  path = require("node:path"),
  crypto = require("node:crypto"),
  os = require("node:os");
const root = path.resolve(__dirname, ".."),
  destination = path.join(os.homedir(), ".pawear-backups", "source-cleanup-20260912");
const hash = (b) => crypto.createHash("sha256").update(b).digest("hex");
const walk = (dir) =>
  fs
    .readdirSync(dir, { withFileTypes: true })
    .flatMap((e) =>
      e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)],
    );
(async () => {
  const c = await require("mongodb").MongoClient.connect(
    "mongodb://127.0.0.1:27028/pawear?replicaSet=pawearDev",
  );
  let databaseText = "";
  try {
    for (const info of await c.db().listCollections().toArray())
      for await (const doc of c.db().collection(info.name).find())
        databaseText += JSON.stringify(doc);
  } finally {
    await c.close();
  }
  const runtimeText = [
    "controller",
    "models",
    "routes",
    "views",
    "services",
    "middleware",
    "public/javascript",
    "public/js",
    "public/css",
    "public/stylesheet",
  ]
    .flatMap((d) => walk(path.join(root, d)))
    .filter((f) => /\.(js|ejs|css)$/.test(f))
    .map((f) => fs.readFileSync(f, "utf8"))
    .join("\n");
  const candidates = [
    "controller/product-controllers/product-variant-controller.js",
    "services/shopping-services/size-service.js",
    "services/storefront/design-preview.js",
    "public/stylesheet/shared/refinement.css",
  ];
  for (const file of walk(path.join(root, "public/images"))) {
    if (!file.endsWith(".png") || !fs.existsSync(file.slice(0, -4) + ".webp")) continue;
    const relative = path.relative(root, file).replaceAll("\\", "/");
    if (
      !runtimeText.includes(path.basename(file)) &&
      !databaseText.includes(relative.slice("public".length))
    )
      candidates.push(relative);
  }
  const manifest = [];
  for (const relative of candidates) {
    const file = path.resolve(root, relative),
      copy = path.resolve(destination, relative);
    if (
      !file.startsWith(root + path.sep) ||
      !copy.startsWith(path.resolve(destination) + path.sep)
    )
      throw Error("Unsafe path");
    if (!fs.existsSync(file)) continue;
    const bytes = fs.readFileSync(file);
    fs.mkdirSync(path.dirname(copy), { recursive: true });
    fs.writeFileSync(copy, bytes, { flag: "wx" });
    if (hash(fs.readFileSync(copy)) !== hash(bytes))
      throw Error("Archive verification failed");
    fs.unlinkSync(file);
    manifest.push({ file: relative, bytes: bytes.length, sha256: hash(bytes) });
  }
  fs.writeFileSync(
    path.join(destination, "manifest.json"),
    JSON.stringify(manifest, null, 2),
    { flag: "wx" },
  );
  console.log(
    JSON.stringify({
      archived: manifest.length,
      bytes: manifest.reduce((n, f) => n + f.bytes, 0),
      destination,
    }),
  );
})().catch((e) => {
  console.error(e.message);
  process.exitCode = 1;
});
